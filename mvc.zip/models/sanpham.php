<?php 
class sanpham extends model{
    var $table = 'sanpham';
    function __construct()
    {
        parent::__construct();
    }
}