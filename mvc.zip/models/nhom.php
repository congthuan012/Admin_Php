<?php 
class nhom extends model
{
    var $table = 'nhomquantri';
    function __construct()
    {
        parent::__construct();
    }
}