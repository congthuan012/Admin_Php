<?php
/**
 * 
 */
class lienhekh extends model
{
	var $table = 'lien_he_kh';
	function __construct()
	{
		parent::__construct();
	}
}