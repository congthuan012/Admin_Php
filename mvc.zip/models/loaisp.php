<?php 
class loaisp extends model{
    var $table = 'loaisanpham'; 
    function __construct()
    {
        parent::__construct();
    }
}