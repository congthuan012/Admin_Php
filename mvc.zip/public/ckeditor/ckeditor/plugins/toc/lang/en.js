﻿CKEDITOR.plugins.setLang( 'toc', 'en', {
	tooltip : 'Create Table of Contents',
	notitles: 'No Headings available! \nPlease format some text as "Heading", "Heading 2" etc. within the editor',
	ToC: 'Table of Contents'
});
